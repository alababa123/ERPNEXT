from .start import dp
from .waiting_handler import dp
from .registration_handler import dp
from .foreman_handler import dp
from .worker_handler import dp
from .manager_handler import dp
__all__ = ["dp"]
