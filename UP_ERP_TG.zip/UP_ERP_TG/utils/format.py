import string

def format_phone(phone: string):
    return ''.join(phone.split(" "))

