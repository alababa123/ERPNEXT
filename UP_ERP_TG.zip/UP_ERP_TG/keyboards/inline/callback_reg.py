from aiogram.utils.callback_data import CallbackData

reg_callback = CallbackData("reg", "bool")