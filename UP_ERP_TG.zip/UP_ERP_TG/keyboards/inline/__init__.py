from .foreman_menu import foreman_menu
from .reg_buttons import end_reg
from .manage_menu import manage_menu
from .worker import worker_menu, worker_menu_company
