from aiogram.utils.callback_data import CallbackData

f_m = CallbackData("serv", "name")